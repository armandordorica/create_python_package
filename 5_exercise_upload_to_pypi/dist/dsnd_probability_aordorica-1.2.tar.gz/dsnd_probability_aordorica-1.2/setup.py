from setuptools import setup

setup(name='dsnd_probability_aordorica',
      version='1.2',
      description='Gaussian and Binomial  distributions',
      packages=['dsnd_probability_aordorica'],
      author = 'Armando Ordorica',
      author_email = 'armandordorica@gmail.com',
      zip_safe=False)
